sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/core/Fragment"
], function (Controller, JSONModel, ResourceModel, Fragment, oView) {
	"use strict";

	return Controller.extend("sap.ui.cineplex.controller.App", {

		onInit: function () {
			oView = this.getView()
			oView.addStyleClass(sap.ui.Device.support.touch ? "sapUiSizeCozy" : "sapUiSizeCompact");

			this.setViewModel();
			this.loadUi()
		},

		setViewModel: function () {
			this.oStrings = new ResourceModel({
				bundleUrl: "i18n/i18n.properties",
				fallbackLocale: "it",
				supportedLocales: [
					"en",
					"it"
				]
			});

			this.oUser = new JSONModel();
			this.oUI = new JSONModel();

			oView.setModel(this.oUI, "UI");
			oView.setModel(this.oUser, "User");
			oView.setModel(this.oStrings, "Strings");
		},

		loadUi: function(){
			this.oUI.oData.loginAccepted = false;
			this.oUI.refresh()
		},

		openLoginDialog: function () {

			if (!this.pLoginDialog) {
				this.pLoginDialog = Fragment.load({
					id: oView.getId(),
					name: "sap.ui.cineplex.view.Login",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this.pLoginDialog.then(function (oDialog) {
				oDialog.open();
			});
		},

		okLoginDialog: function(){

			$.ajax({
				url: "",
				type: 'POST',
				data: $.param({"nomorDosir": "01041701288", "kodeCabang": "A02"}),
				contentType: 'application/x-www-form-urlencoded',
				success: function(data){
					console.log("success"+data);
				},
				error: function(e){
					console.log("error: "+e);
				}
			  });


		},

		backLoginDialog: function(){
			this.pLoginDialog.then(function (oDialog) {
				oDialog.close();
			});
		},

	});

});